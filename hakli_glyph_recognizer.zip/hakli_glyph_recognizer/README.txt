this uses

https://hytra3.github.io/hakli-recognizer/

update
the hakli-symbols.JSON as well as symbols and examples folders

base version is based on Al-Jallad, A. [in press (2025)]. The Decipherment of the Dhofari Script: Three halḥam 
abecedaries and the first glimpses into the corpus. Jaarbericht Ex Oriente Lux (JEOL) 49.  

chart on pages 10-11 KMG 120-126 and KMD 28-31